#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int * array;
    // Add more fields here
    
} ArrayList;


void init_arraylist(ArrayList *list, int capacity)
{
    printf("implement init_arraylist\n");
    // dynamically allocate space for the array
    // initialize the size, capacity, and current position
}


void clear(ArrayList *list)
{
    printf("Implement clear\n");
    // clear the list but do not free the array
    // modify the size, capacity, and current position
}

int get_size(ArrayList *list)
{
    printf("Implement get_size\n");
    return -1;
}


void resize(ArrayList *list, int new_capacity)
{
    printf("Implement resize\n");
    // allocate space for new array with new_capacity
    // print log message
}


void append(ArrayList *list, int value)
{
    printf("Implement append\n");
    // call resize if necessary
    // add value to the end of the list
}


void insert(ArrayList *list, int value)
{
    printf("Implement insert\n");
    // call resize if necessary
    // shift the elements to the right to make space
    // add value at the current position
}


int remove_at_current(ArrayList *list)
{
    printf("Implement remove_at_current\n");
    return -1;
    // save the value of the current element in a variable
    // shift the elements to the left to fill the gap
    // change the size, and current position as necessary
    // call resize if necessary
    // return the saved value
}

int find(ArrayList *list, int value)
{
    printf("Implement find\n");
    return -1;
    // traverse the list and return the position of the value
    // return -1 if the value is not found
}


void move_to_start(ArrayList *list)
{
    printf("Implement move_to_start\n");
    // consider the cases when the list is empty
}


void move_to_end(ArrayList *list)
{
    printf("Implement move_to_end\n");
    // consider the cases when the list is empty
}


void prev(ArrayList *list)
{
    printf("Implement prev\n");
    // no change if the current position is at the start
}


void next(ArrayList *list)
{
    printf("Implement next\n");
    // no change if the current position is at the end
}


void move_to_position(ArrayList *list, int position)
{
    printf("Implement move_to_position\n");
    
}


int get_current_position(ArrayList *list)
{
    printf("Implement get_current_position\n");
    return -1;
}


int get_current_element(ArrayList *list)
{
    printf("Implement get_current_element\n");
    return -1;
}


void print_list(ArrayList *list)
{
    printf("< list elements here >");
}


void free_list(ArrayList *list)
{
    printf("Implement free_list\n");
    // free the array before terminating the program
}


